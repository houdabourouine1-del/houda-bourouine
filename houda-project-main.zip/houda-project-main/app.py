from flask import Flask, request, redirect, url_for, render_template, flash
import pyodbc

app = Flask(__name__)
app.secret_key = "secret_key"

# Configuration de la connexion SQL Server
conn_str = (
    r'DRIVER={ODBC Driver 18 for SQL Server};'
    r'SERVER=.\SQLEXPRESS;'
    r'DATABASE=SchoolDB;'
    r'Trusted_Connection=yes;'
    r'TrustServerCertificate=yes;'
)

def get_db_connection():
    return pyodbc.connect(conn_str)

@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Stats for dashboard
    cursor.execute("SELECT COUNT(*) FROM Students")
    student_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM Subjects")
    subject_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM Grades")
    grade_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM Trainers")
    trainer_count = cursor.fetchone()[0]
    
    # Rankings
    query = """
    SELECT s.StudentID, s.FullName, COALESCE(AVG(g.Score), 0) as Average
    FROM Students s
    LEFT JOIN Grades g ON s.StudentID = g.StudentID
    GROUP BY s.StudentID, s.FullName
    ORDER BY Average DESC
    """
    cursor.execute(query)
    rankings = cursor.fetchall()
    
    conn.close()
    return render_template('index.html', 
                           student_count=student_count, 
                           subject_count=subject_count, 
                           grade_count=grade_count,
                           trainer_count=trainer_count,
                           rankings=rankings)

@app.route('/trainers', methods=['GET', 'POST'])
def trainers():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        name = request.form['name']
        if name:
            cursor.execute("INSERT INTO Trainers (FullName) VALUES (?)", (name,))
            conn.commit()
            flash('Formateur ajouté !', 'success')
        return redirect(url_for('trainers'))
    
    cursor.execute("SELECT * FROM Trainers")
    trainers_list = cursor.fetchall()
    conn.close()
    return render_template('trainers.html', trainers=trainers_list)

@app.route('/edit_trainer/<int:id>', methods=['GET', 'POST'])
def edit_trainer(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        cursor.execute("UPDATE Trainers SET FullName = ? WHERE TrainerID = ?", (name, id))
        conn.commit()
        conn.close()
        flash('Formateur mis à jour !', 'success')
        return redirect(url_for('trainers'))
    
    cursor.execute("SELECT * FROM Trainers WHERE TrainerID = ?", (id,))
    trainer = cursor.fetchone()
    conn.close()
    return render_template('edit_trainer.html', trainer=trainer)

@app.route('/delete_trainer/<int:id>')
def delete_trainer(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM TrainerSubjects WHERE TrainerID = ?", (id,))
        cursor.execute("DELETE FROM Trainers WHERE TrainerID = ?", (id,))
        conn.commit()
        flash('Formateur supprimé !', 'danger')
    except Exception as e:
        flash(f'Erreur : {e}', 'warning')
    conn.close()
    return redirect(url_for('trainers'))

@app.route('/students', methods=['GET', 'POST'])
def students():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        name = request.form['name']
        if name:
            cursor.execute("INSERT INTO Students (FullName) VALUES (?)", (name,))
            conn.commit()
            flash('Étudiant ajouté !', 'success')
        return redirect(url_for('students'))
    
    cursor.execute("SELECT * FROM Students")
    students_list = cursor.fetchall()
    conn.close()
    return render_template('students.html', students=students_list)

@app.route('/edit_student/<int:id>', methods=['GET', 'POST'])
def edit_student(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        cursor.execute("UPDATE Students SET FullName = ? WHERE StudentID = ?", (name, id))
        conn.commit()
        conn.close()
        flash('Étudiant mis à jour !', 'success')
        return redirect(url_for('students'))
    
    cursor.execute("SELECT * FROM Students WHERE StudentID = ?", (id,))
    student = cursor.fetchone()
    conn.close()
    return render_template('edit_student.html', student=student)

@app.route('/delete_student/<int:id>')
def delete_student(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM Grades WHERE StudentID = ?", (id,))
        cursor.execute("DELETE FROM Students WHERE StudentID = ?", (id,))
        conn.commit()
        flash('Étudiant supprimé !', 'danger')
    except Exception as e:
        flash(f'Erreur : {e}', 'warning')
    conn.close()
    return redirect(url_for('students'))

@app.route('/subjects', methods=['GET', 'POST'])
def subjects():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        if 'add_subject' in request.form:
            name = request.form['name']
            if name:
                cursor.execute("INSERT INTO Subjects (SubjectName) VALUES (?)", (name,))
                conn.commit()
                flash('Matière ajoutée !', 'success')
        elif 'assign_trainer' in request.form:
            sub_id = request.form['subject_id']
            t_id = request.form['trainer_id']
            if sub_id and t_id:
                try:
                    cursor.execute("INSERT INTO TrainerSubjects (TrainerID, SubjectID) VALUES (?, ?)", (t_id, sub_id))
                    conn.commit()
                    flash('Formateur assigné à la matière !', 'success')
                except:
                    flash('Cette relation existe déjà.', 'warning')
        return redirect(url_for('subjects'))
    
    cursor.execute("SELECT * FROM Subjects")
    subjects_list = cursor.fetchall()
    
    cursor.execute("SELECT * FROM Trainers")
    trainers_list = cursor.fetchall()
    
    query = """
    SELECT ts.TrainerID, ts.SubjectID, s.SubjectName, t.FullName
    FROM TrainerSubjects ts
    JOIN Subjects s ON ts.SubjectID = s.SubjectID
    JOIN Trainers t ON ts.TrainerID = t.TrainerID
    """
    cursor.execute(query)
    assignments = cursor.fetchall()
    
    conn.close()
    return render_template('subjects.html', subjects=subjects_list, trainers=trainers_list, assignments=assignments)

@app.route('/edit_subject/<int:id>', methods=['GET', 'POST'])
def edit_subject(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        cursor.execute("UPDATE Subjects SET SubjectName = ? WHERE SubjectID = ?", (name, id))
        conn.commit()
        conn.close()
        flash('Matière mise à jour !', 'success')
        return redirect(url_for('subjects'))
    
    cursor.execute("SELECT * FROM Subjects WHERE SubjectID = ?", (id,))
    subject = cursor.fetchone()
    conn.close()
    return render_template('edit_subject.html', subject=subject)

@app.route('/delete_subject/<int:id>')
def delete_subject(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM Grades WHERE SubjectID = ?", (id,))
        cursor.execute("DELETE FROM TrainerSubjects WHERE SubjectID = ?", (id,))
        cursor.execute("DELETE FROM Subjects WHERE SubjectID = ?", (id,))
        conn.commit()
        flash('Matière supprimée !', 'danger')
    except Exception as e:
        flash(f'Erreur : {e}', 'warning')
    conn.close()
    return redirect(url_for('subjects'))

@app.route('/unassign/<int:t_id>/<int:s_id>')
def unassign(t_id, s_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM TrainerSubjects WHERE TrainerID = ? AND SubjectID = ?", (t_id, s_id))
    conn.commit()
    conn.close()
    flash('Assignation supprimée.', 'info')
    return redirect(url_for('subjects'))

@app.route('/grades', methods=['GET', 'POST'])
def grades():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        s_id = request.form['student_id']
        sub_id = request.form['subject_id']
        score = request.form['score']
        if s_id and sub_id and score:
            cursor.execute("INSERT INTO Grades (StudentID, SubjectID, Score) VALUES (?, ?, ?)", (s_id, sub_id, score))
            conn.commit()
            flash('Note enregistrée !', 'success')
        return redirect(url_for('grades'))
    
    cursor.execute("SELECT StudentID, FullName FROM Students")
    students_list = cursor.fetchall()
    
    cursor.execute("SELECT SubjectID, SubjectName FROM Subjects")
    subjects_list = cursor.fetchall()
    
    query = """
    SELECT g.GradeID, s.FullName, sub.SubjectName, g.Score
    FROM Grades g
    JOIN Students s ON g.StudentID = s.StudentID
    JOIN Subjects sub ON g.SubjectID = sub.SubjectID
    """
    cursor.execute(query)
    grades_list = cursor.fetchall()
    
    conn.close()
    return render_template('grades.html', students=students_list, subjects=subjects_list, grades=grades_list)

@app.route('/edit_grade/<int:id>', methods=['GET', 'POST'])
def edit_grade(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == 'POST':
        score = request.form['score']
        cursor.execute("UPDATE Grades SET Score = ? WHERE GradeID = ?", (score, id))
        conn.commit()
        conn.close()
        flash('Note mise à jour !', 'success')
        return redirect(url_for('grades'))
    
    query = """
    SELECT g.GradeID, s.FullName, sub.SubjectName, g.Score
    FROM Grades g
    JOIN Students s ON g.StudentID = s.StudentID
    JOIN Subjects sub ON g.SubjectID = sub.SubjectID
    WHERE g.GradeID = ?
    """
    cursor.execute(query, (id,))
    grade = cursor.fetchone()
    conn.close()
    return render_template('edit_grade.html', grade=grade)

@app.route('/delete_grade/<int:id>')
def delete_grade(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Grades WHERE GradeID = ?", (id,))
    conn.commit()
    conn.close()
    flash('Note supprimée !', 'danger')
    return redirect(url_for('grades'))

@app.route('/report_card/<int:student_id>')
def report_card(student_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT FullName FROM Students WHERE StudentID = ?", (student_id,))
    student = cursor.fetchone()
    
    query = """
    SELECT sub.SubjectName, g.Score
    FROM Grades g
    JOIN Subjects sub ON g.SubjectID = sub.SubjectID
    WHERE g.StudentID = ?
    """
    cursor.execute(query, (student_id,))
    grades = cursor.fetchall()
    
    conn.close()
    return render_template('report_card.html', student=student, grades=grades)

if __name__ == '__main__':
    app.run(debug=True)
