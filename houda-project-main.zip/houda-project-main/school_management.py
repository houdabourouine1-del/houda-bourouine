import pyodbc

# Configuration de la connexion
conn_str = (
    r'DRIVER={ODBC Driver 18 for SQL Server};'
    r'SERVER=.\SQLEXPRESS;'
    r'DATABASE=SchoolDB;'
    r'Trusted_Connection=yes;'
    r'TrustServerCertificate=yes;'
)

def get_connection():
    return pyodbc.connect(conn_str)

def add_student(name):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Students (FullName) VALUES (?)", (name,))
    conn.commit()
    print(f"Étudiant '{name}' ajouté avec succès.")
    conn.close()

def add_subject(name):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Subjects (SubjectName) VALUES (?)", (name,))
    conn.commit()
    print(f"Matière '{name}' ajoutée avec succès.")
    conn.close()

def add_grade(student_id, subject_id, score):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Grades (StudentID, SubjectID, Score) VALUES (?, ?, ?)", (student_id, subject_id, score))
    conn.commit()
    print(f"Note {score} ajoutée pour l'étudiant ID {student_id} dans la matière ID {subject_id}.")
    conn.close()

def calculate_average(student_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT AVG(Score) FROM Grades WHERE StudentID = ?", (student_id,))
    row = cursor.fetchone()
    conn.close()
    if row and row[0] is not None:
        return row[0]
    return 0

def rank_students():
    conn = get_connection()
    cursor = conn.cursor()
    query = """
    SELECT s.FullName, COALESCE(AVG(g.Score), 0) as Average
    FROM Students s
    LEFT JOIN Grades g ON s.StudentID = g.StudentID
    GROUP BY s.FullName
    ORDER BY Average DESC
    """
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    print("\nClassement des étudiants :")
    for i, row in enumerate(rows, 1):
        print(f"{i}. {row.FullName} - Moyenne : {row.Average:.2f}")

def display_report_card(student_id):
    conn = get_connection()
    cursor = conn.cursor()
    
    # Get student info
    cursor.execute("SELECT FullName FROM Students WHERE StudentID = ?", (student_id,))
    student = cursor.fetchone()
    if not student:
        print("Étudiant non trouvé.")
        conn.close()
        return

    # Get grades
    query = """
    SELECT sub.SubjectName, g.Score
    FROM Grades g
    JOIN Subjects sub ON g.SubjectID = sub.SubjectID
    WHERE g.StudentID = ?
    """
    cursor.execute(query, (student_id,))
    grades = cursor.fetchall()
    
    print(f"\nBulletin de : {student.FullName}")
    print("-" * 30)
    total_score = 0
    for subject, score in grades:
        print(f"{subject:20} : {score}")
        total_score += score
    
    if grades:
        avg = total_score / len(grades)
        print("-" * 30)
        print(f"{'Moyenne Générale':20} : {avg:.2f}")
    else:
        print("Aucune note enregistrée.")
    
    conn.close()

def list_students():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT StudentID, FullName FROM Students")
    rows = cursor.fetchall()
    conn.close()
    print("\nListe des étudiants :")
    for row in rows:
        print(f"ID: {row.StudentID} - Nom: {row.FullName}")

def list_subjects():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT SubjectID, SubjectName FROM Subjects")
    rows = cursor.fetchall()
    conn.close()
    print("\nListe des matières :")
    for row in rows:
        print(f"ID: {row.SubjectID} - Nom: {row.SubjectName}")

if __name__ == "__main__":
    # Exemple d'utilisation
    print("--- Gestion de l'école ---")
    
    # Ajout de données de test si vide
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM Students")
    if cursor.fetchone()[0] == 0:
        add_student("Alice")
        add_student("Bob")
        add_subject("Maths")
        add_subject("Français")
        add_grade(1, 1, 15)
        add_grade(1, 2, 12)
        add_grade(2, 1, 10)
        add_grade(2, 2, 14)
    conn.close()

    # Menu simple
    while True:
        print("\n1. Ajouter un étudiant")
        print("2. Ajouter une matière")
        print("3. Ajouter une note")
        print("4. Liste des étudiants")
        print("5. Classement des étudiants")
        print("6. Afficher le bulletin d'un étudiant")
        print("7. Quitter")
        
        choice = input("Choisissez une option : ")
        
        if choice == '1':
            name = input("Nom de l'étudiant : ")
            add_student(name)
        elif choice == '2':
            name = input("Nom de la matière : ")
            add_subject(name)
        elif choice == '3':
            list_students()
            s_id = int(input("ID de l'étudiant : "))
            list_subjects()
            sub_id = int(input("ID de la matière : "))
            score = float(input("Note : "))
            add_grade(s_id, sub_id, score)
        elif choice == '4':
            list_students()
        elif choice == '5':
            rank_students()
        elif choice == '6':
            list_students()
            s_id = int(input("ID de l'étudiant : "))
            display_report_card(s_id)
        elif choice == '7':
            break
        else:
            print("Option invalide.")
