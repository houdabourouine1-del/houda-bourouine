# Project: School Management System

## Prerequisites
- Python 3.x
- SQL Server Express (`.\SQLEXPRESS`)
- ODBC Driver 18 for SQL Server
- `pyodbc` and `flask` libraries

## Setup Instructions

1.  **Initialize the Database:**
    Before running the application, you must create the database and its tables. Run the following script:
    ```bash
    python create_db.py
    ```
    This script will:
    - Connect to your local SQL Server instance.
    - Create the `SchoolDB` database if it doesn't exist.
    - Create the necessary tables: `Students`, `Subjects`, `Trainers`, `TrainerSubjects`, and `Grades`.

2.  **Run the Application:**
    After the database is initialized, start the Flask server:
    ```bash
    python app.py
    ```
    The application will be available at `http://127.0.0.1:5000`.

## Troubleshooting

- **Login Failed:** Ensure that your SQL Server instance is configured to allow Windows Authentication and that your current user has permission to create databases.
- **Driver Not Found:** If you have a different ODBC driver version, update the `conn_str` in `app.py`, `school_management.py`, and `create_db.py`.
