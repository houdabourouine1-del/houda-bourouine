import pyodbc

# Connection string to connect to 'master' database to create 'SchoolDB'
conn_str_master = (
    r'DRIVER={ODBC Driver 18 for SQL Server};'
    r'SERVER=.\SQLEXPRESS;'
    r'DATABASE=master;'
    r'Trusted_Connection=yes;'
    r'TrustServerCertificate=yes;'
)

def create_database():
    try:
        # Connect to master
        print("Connecting to master database...")
        conn = pyodbc.connect(conn_str_master, autocommit=True)
        cursor = conn.cursor()
        
        # Create database if it doesn't exist
        print("Checking if 'SchoolDB' exists...")
        cursor.execute("IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'SchoolDB') CREATE DATABASE SchoolDB")
        print("Database 'SchoolDB' created or already exists.")
        conn.close()
        
        # Now connect to SchoolDB to create tables
        conn_str_school = (
            r'DRIVER={ODBC Driver 18 for SQL Server};'
            r'SERVER=.\SQLEXPRESS;'
            r'DATABASE=SchoolDB;'
            r'Trusted_Connection=yes;'
            r'TrustServerCertificate=yes;'
        )
        print("Connecting to SchoolDB...")
        conn = pyodbc.connect(conn_str_school)
        cursor = conn.cursor()
        
        # Create Students table
        print("Creating tables if they don't exist...")
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Students]') AND type in (N'U'))
        CREATE TABLE Students (
            StudentID INT PRIMARY KEY IDENTITY(1,1),
            FullName NVARCHAR(100) NOT NULL
        )
        """)
        
        # Create Subjects table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Subjects]') AND type in (N'U'))
        CREATE TABLE Subjects (
            SubjectID INT PRIMARY KEY IDENTITY(1,1),
            SubjectName NVARCHAR(100) NOT NULL
        )
        """)
        
        # Create Trainers table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Trainers]') AND type in (N'U'))
        CREATE TABLE Trainers (
            TrainerID INT PRIMARY KEY IDENTITY(1,1),
            FullName NVARCHAR(100) NOT NULL
        )
        """)
        
        # Create TrainerSubjects table (many-to-many)
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TrainerSubjects]') AND type in (N'U'))
        CREATE TABLE TrainerSubjects (
            TrainerID INT REFERENCES Trainers(TrainerID),
            SubjectID INT REFERENCES Subjects(SubjectID),
            PRIMARY KEY (TrainerID, SubjectID)
        )
        """)
        
        # Create Grades table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Grades]') AND type in (N'U'))
        CREATE TABLE Grades (
            GradeID INT PRIMARY KEY IDENTITY(1,1),
            StudentID INT REFERENCES Students(StudentID),
            SubjectID INT REFERENCES Subjects(SubjectID),
            Score FLOAT NOT NULL
        )
        """)
        
        conn.commit()
        print("Tables created successfully.")
        conn.close()
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    create_database()
